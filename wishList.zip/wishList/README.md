Unified wishlist application for several popular websites made userfriendly with the use of webscrapping.

Technologies:-  
Frontend: Flask frontend using jinja template.  
Backend: Flask py  
Database: SQLAlchemy  

Deployment: https://liadd.herokuapp.com/
